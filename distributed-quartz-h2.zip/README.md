
# Distributed Quartz with H2 (Demo)

## Run
mvn spring-boot:run

## H2 Console
http://localhost:8080/h2-console

JDBC URL:
jdbc:h2:mem:quartzdb

## Test Job
POST:
http://localhost:8080/jobs/schedule?jobName=test&cron=0/10 * * * * ?

## Notes
- H2 is in-memory, so clustering across multiple instances won't persist.
- Use MySQL/Postgres for real distributed clustering.
