
package com.example.quartz.controller;

import com.example.quartz.job.SampleJob;
import lombok.RequiredArgsConstructor;
import org.quartz.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobController {

    private final Scheduler scheduler;

    @PostMapping("/schedule")
    public String scheduleJob(@RequestParam String jobName,
                              @RequestParam String cron) throws Exception {

        JobDetail jobDetail = JobBuilder.newJob(SampleJob.class)
                .withIdentity(jobName)
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .withIdentity(jobName + "-trigger")
                .withSchedule(CronScheduleBuilder.cronSchedule(cron))
                .build();

        scheduler.scheduleJob(jobDetail, trigger);
        return "Job scheduled";
    }
}
