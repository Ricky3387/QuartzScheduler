
package com.example.quartz.job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.springframework.stereotype.Component;

@Component
public class SampleJob implements Job {

    @Override
    public void execute(JobExecutionContext context) {
        System.out.println("Executing job on instance: " + Thread.currentThread().getName());
    }
}
