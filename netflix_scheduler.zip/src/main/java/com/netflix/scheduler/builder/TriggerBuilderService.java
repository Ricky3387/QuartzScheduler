
package com.netflix.scheduler.builder;

import com.netflix.scheduler.model.ScheduleRequest;
import org.quartz.*;
import org.springframework.stereotype.Component;

import java.time.*;
import java.util.*;

@Component
public class TriggerBuilderService {

    public Trigger build(ScheduleRequest r) {
        switch (r.getFrequency()) {
            case "MINUTELY": return simple(r, r.getRepeatEvery(), ChronoUnit.MINUTES);
            case "HOURLY": return simple(r, r.getRepeatEvery(), ChronoUnit.HOURS);
            case "DAILY": return simple(r, r.getRepeatEvery()*24, ChronoUnit.HOURS);
            default: throw new RuntimeException("Unsupported");
        }
    }

    private Trigger simple(ScheduleRequest r, int interval, ChronoUnit unit) {

        SimpleScheduleBuilder builder = SimpleScheduleBuilder.simpleSchedule()
            .repeatForever()
            .withMisfireHandlingInstructionNextWithRemainingCount();

        if(unit == ChronoUnit.MINUTES)
            builder.withIntervalInMinutes(interval);
        else
            builder.withIntervalInHours(interval);

        return TriggerBuilder.newTrigger()
            .withIdentity(r.getId()+"_trigger")
            .startAt(start(r))
            .endAt(end(r))
            .withSchedule(builder)
            .build();
    }

    private Date start(ScheduleRequest r){
        ZoneId z = ZoneId.of(Optional.ofNullable(r.getTimezone()).orElse("UTC"));
        LocalDate d = Optional.ofNullable(r.getStartDate()).orElse(LocalDate.now());
        LocalTime t = Optional.ofNullable(r.getStartTime()).orElse(LocalTime.now().plusMinutes(1));
        return Date.from(d.atTime(t).atZone(z).toInstant());
    }

    private Date end(ScheduleRequest r){
        if(r.getEndDate()==null) return null;
        ZoneId z = ZoneId.of(r.getTimezone());
        return Date.from(r.getEndDate().atTime(23,59,59).atZone(z).toInstant());
    }
}
