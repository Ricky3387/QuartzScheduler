
package com.netflix.scheduler.controller;

import com.netflix.scheduler.model.ScheduleRequest;
import com.netflix.scheduler.service.SchedulerService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/scheduler")
public class SchedulerController {

    private final SchedulerService service;

    public SchedulerController(SchedulerService service){
        this.service = service;
    }

    @PostMapping
    public String create(@RequestBody ScheduleRequest r) throws Exception {
        service.create(r);
        return "created";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) throws Exception {
        service.delete(id);
        return "deleted";
    }
}
