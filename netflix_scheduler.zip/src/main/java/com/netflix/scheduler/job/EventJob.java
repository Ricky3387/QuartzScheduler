
package com.netflix.scheduler.job;

import org.quartz.*;

public class EventJob implements Job {
    @Override
    public void execute(JobExecutionContext context) {
        System.out.println("Publishing event: " + context.getJobDetail().getKey().getName());
    }
}
