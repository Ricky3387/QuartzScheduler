
package com.netflix.scheduler.model;

import lombok.Data;
import java.time.*;
import java.util.List;

@Data
public class ScheduleRequest {
    private String id;
    private String frequency;
    private Integer repeatEvery;

    private LocalDate startDate;
    private LocalTime startTime;
    private LocalDate endDate;

    private LocalTime windowStart;
    private LocalTime windowEnd;

    private List<DayOfWeek> daysOfWeek;
    private String timezone;
}
