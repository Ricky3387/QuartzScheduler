
package com.netflix.scheduler.service;

import com.netflix.scheduler.builder.TriggerBuilderService;
import com.netflix.scheduler.model.ScheduleRequest;
import com.netflix.scheduler.job.EventJob;
import org.quartz.*;
import org.springframework.stereotype.Service;

@Service
public class SchedulerService {

    private final Scheduler scheduler;
    private final TriggerBuilderService builder;

    public SchedulerService(Scheduler scheduler, TriggerBuilderService builder){
        this.scheduler = scheduler;
        this.builder = builder;
    }

    public void create(ScheduleRequest r) throws Exception {
        JobDetail job = JobBuilder.newJob(EventJob.class)
            .withIdentity(r.getId())
            .storeDurably()
            .build();

        scheduler.scheduleJob(job, builder.build(r));
    }

    public void delete(String id) throws Exception {
        scheduler.deleteJob(JobKey.jobKey(id));
    }
}
