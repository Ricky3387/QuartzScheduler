package com.example.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.quartz.*;
import com.example.model.*;
import com.example.factory.*;
import com.example.job.*;

@RestController
@RequestMapping("/schedule")
public class SchedulerController {

    @Autowired
    private Scheduler scheduler;

    @PostMapping
    public String create(@RequestBody ScheduleRequest req) throws Exception {

        JobDetail job = JobBuilder.newJob(DummyJob.class)
            .withIdentity(req.id)
            .build();

        scheduler.addJob(job, true);

        for (Trigger t : QuartzTriggerFactory.build(req)) {
            scheduler.scheduleJob(job, t);
        }

        return "Scheduled";
    }
}
