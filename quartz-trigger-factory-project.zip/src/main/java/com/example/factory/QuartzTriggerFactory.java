package com.example.factory;

import com.example.model.*;
import org.quartz.*;
import java.util.*;

public class QuartzTriggerFactory {

    public static List<Trigger> build(ScheduleRequest req) {

        if (req.frequency == Frequency.MINUTELY || req.frequency == Frequency.HOURLY) {
            return List.of(
                TriggerBuilder.newTrigger()
                .withIdentity(req.id)
                .startNow()
                .withSchedule(
                    DailyTimeIntervalScheduleBuilder.dailyTimeIntervalSchedule()
                    .startingDailyAt(TimeOfDay.hourMinuteAndSecondOfDay(
                        req.startTime.getHour(), req.startTime.getMinute(), 0))
                    .endingDailyAt(TimeOfDay.hourMinuteAndSecondOfDay(
                        req.endTime.getHour(), req.endTime.getMinute(), 0))
                    .withInterval(req.interval,
                        req.frequency == Frequency.MINUTELY ?
                        DateBuilder.IntervalUnit.MINUTE :
                        DateBuilder.IntervalUnit.HOUR)
                ).build()
            );
        }

        String cron = String.format("0 %d %d * * ?",
            req.startTime.getMinute(), req.startTime.getHour());

        return List.of(
            TriggerBuilder.newTrigger()
            .withIdentity(req.id+"_cron")
            .withSchedule(CronScheduleBuilder.cronSchedule(cron))
            .build()
        );
    }
}
