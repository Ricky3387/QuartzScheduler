package com.example.job;

import org.quartz.*;

public class DummyJob implements Job {
    public void execute(JobExecutionContext ctx) {
        System.out.println("Executed: " + ctx.getJobDetail().getKey());
    }
}
