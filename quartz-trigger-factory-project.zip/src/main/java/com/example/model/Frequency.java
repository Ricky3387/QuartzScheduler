package com.example.model;

public enum Frequency {
    MINUTELY, HOURLY, DAILY
}
