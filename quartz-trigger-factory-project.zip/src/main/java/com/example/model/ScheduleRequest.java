package com.example.model;

import java.time.*;

public class ScheduleRequest {
    public String id;
    public Frequency frequency;
    public int interval;
    public LocalTime startTime;
    public LocalTime endTime;
}
