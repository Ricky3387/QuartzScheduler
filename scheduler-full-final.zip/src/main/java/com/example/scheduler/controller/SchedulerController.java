package com.example.scheduler.controller;

import org.springframework.web.bind.annotation.*;
import com.example.scheduler.service.SchedulerService;
import com.example.scheduler.model.*;

@RestController
@RequestMapping("/api/schedules")
public class SchedulerController {

    private final SchedulerService service;

    public SchedulerController(SchedulerService service) {
        this.service = service;
    }

    @PostMapping
    public String create(@RequestBody ScheduleRequest req) throws Exception {
        service.schedule(req);
        return "scheduled";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) throws Exception {
        service.delete(id);
        return "deleted";
    }
}
