package com.example.scheduler.factory;

import com.example.scheduler.model.*;
import org.quartz.*;
import java.time.*;
import java.util.*;

public class UnifiedTriggerFactory {

    public static List<Trigger> buildTriggers(ScheduleRequest req) {

        switch (req.getFrequency()) {
            case MINUTELY:
            case HOURLY:
            case DAILY:
                return List.of(buildSimple(req));
            case MONTHLY:
                return List.of(buildMonthly(req));
            case YEARLY:
                return List.of(buildYearly(req));
            default:
                throw new IllegalArgumentException();
        }
    }

    private static Trigger buildSimple(ScheduleRequest req) {

        long interval = switch (req.getFrequency()) {
            case MINUTELY -> req.getRepeatInterval() * 60_000L;
            case HOURLY -> req.getRepeatInterval() * 3600_000L;
            case DAILY -> req.getRepeatInterval() * 86400_000L;
            default -> throw new IllegalArgumentException();
        };

        return TriggerBuilder.newTrigger()
                .withIdentity(req.getId() + "_simple")
                .startAt(toDate(req.getStartDate(), req.getStartTime()))
                .endAt(req.getEndDate() != null ? toDate(req.getEndDate(), req.getEndTime()) : null)
                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInMilliseconds(interval)
                        .repeatForever())
                .build();
    }

    private static Trigger buildMonthly(ScheduleRequest req) {
        LocalDate d = adjust(req.getStartDate(), req.getStrategy());
        return TriggerBuilder.newTrigger()
                .withIdentity(req.getId() + "_monthly")
                .startAt(toDate(d, req.getStartTime()))
                .withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule()
                        .withInterval(req.getRepeatInterval(), DateBuilder.IntervalUnit.MONTH))
                .build();
    }

    private static Trigger buildYearly(ScheduleRequest req) {
        LocalDate d = adjust(req.getStartDate(), req.getStrategy());
        return TriggerBuilder.newTrigger()
                .withIdentity(req.getId() + "_yearly")
                .startAt(toDate(d, req.getStartTime()))
                .withSchedule(CalendarIntervalScheduleBuilder.calendarIntervalSchedule()
                        .withInterval(req.getRepeatInterval(), DateBuilder.IntervalUnit.YEAR))
                .build();
    }

    private static LocalDate adjust(LocalDate date, DateAdjustmentStrategy strategy) {
        if (strategy == null) return date;
        switch (strategy) {
            case LAST_DAY_OF_MONTH:
                return date.withDayOfMonth(date.lengthOfMonth());
            case FEB_28:
                if (date.getMonthValue()==2 && date.getDayOfMonth()==29)
                    return LocalDate.of(date.getYear(),2,28);
                return date;
            case MARCH_1:
                if (date.getMonthValue()==2 && date.getDayOfMonth()==29)
                    return LocalDate.of(date.getYear(),3,1);
                return date;
            default:
                return date;
        }
    }

    private static Date toDate(LocalDate d, LocalTime t) {
        if (d == null) return new Date();
        return Date.from(LocalDateTime.of(d, t!=null?t:LocalTime.MIDNIGHT)
                .atZone(ZoneId.systemDefault()).toInstant());
    }
}
