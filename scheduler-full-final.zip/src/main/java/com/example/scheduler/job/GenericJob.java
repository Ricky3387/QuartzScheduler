package com.example.scheduler.job;

import org.quartz.*;

public class GenericJob implements Job {
    @Override
    public void execute(JobExecutionContext context) {
        System.out.println("Executing: " + context.getJobDetail().getKey());
    }
}
