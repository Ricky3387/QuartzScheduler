package com.example.scheduler.model;

public enum DateAdjustmentStrategy {
    LAST_DAY_OF_MONTH, FEB_28, MARCH_1, SKIP
}
