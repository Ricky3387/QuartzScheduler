package com.example.scheduler.model;

public enum Frequency {
    MINUTELY, HOURLY, DAILY, MONTHLY, YEARLY
}
