package com.example.scheduler.model;

import java.time.*;

public class ScheduleRequest {

    private String id;
    private Frequency frequency;
    private int repeatInterval;
    private LocalTime startTime;
    private LocalTime endTime;
    private boolean allDay;
    private LocalDate startDate;
    private LocalDate endDate;
    private ZoneId zoneId;
    private DateAdjustmentStrategy strategy;

    public String getId(){return id;}
    public void setId(String id){this.id=id;}
    public Frequency getFrequency(){return frequency;}
    public void setFrequency(Frequency frequency){this.frequency=frequency;}
    public int getRepeatInterval(){return repeatInterval;}
    public void setRepeatInterval(int repeatInterval){this.repeatInterval=repeatInterval;}
    public LocalTime getStartTime(){return startTime;}
    public void setStartTime(LocalTime startTime){this.startTime=startTime;}
    public LocalTime getEndTime(){return endTime;}
    public void setEndTime(LocalTime endTime){this.endTime=endTime;}
    public boolean isAllDay(){return allDay;}
    public void setAllDay(boolean allDay){this.allDay=allDay;}
    public LocalDate getStartDate(){return startDate;}
    public void setStartDate(LocalDate startDate){this.startDate=startDate;}
    public LocalDate getEndDate(){return endDate;}
    public void setEndDate(LocalDate endDate){this.endDate=endDate;}
    public ZoneId getZoneId(){return zoneId;}
    public void setZoneId(ZoneId zoneId){this.zoneId=zoneId;}
    public DateAdjustmentStrategy getStrategy(){return strategy;}
    public void setStrategy(DateAdjustmentStrategy strategy){this.strategy=strategy;}
}
