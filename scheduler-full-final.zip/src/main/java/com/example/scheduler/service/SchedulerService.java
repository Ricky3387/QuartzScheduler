package com.example.scheduler.service;

import org.quartz.*;
import org.springframework.stereotype.Service;
import com.example.scheduler.factory.UnifiedTriggerFactory;
import com.example.scheduler.model.ScheduleRequest;
import com.example.scheduler.job.GenericJob;
import java.util.*;

@Service
public class SchedulerService {

    private final Scheduler scheduler;

    public SchedulerService(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    public void schedule(ScheduleRequest req) throws Exception {

        JobDetail job = JobBuilder.newJob(GenericJob.class)
                .withIdentity(req.getId())
                .build();

        scheduler.addJob(job, true);

        for (Trigger t : UnifiedTriggerFactory.buildTriggers(req)) {
            scheduler.scheduleJob(t);
        }
    }

    public void delete(String id) throws Exception {
        scheduler.deleteJob(new JobKey(id));
    }
}
