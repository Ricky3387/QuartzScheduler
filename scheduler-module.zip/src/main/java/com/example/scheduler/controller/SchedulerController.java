
package com.example.scheduler.controller;

import com.example.scheduler.domain.ScheduleRequest;
import com.example.scheduler.service.SchedulerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/scheduler")
public class SchedulerController {

    @Autowired
    private SchedulerService service;

    @PostMapping
    public String schedule(@RequestBody ScheduleRequest req) throws Exception {
        String id = UUID.randomUUID().toString();
        service.schedule(id, req);
        return id;
    }
}
