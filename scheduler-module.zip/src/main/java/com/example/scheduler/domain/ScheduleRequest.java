
package com.example.scheduler.domain;

import java.time.*;
import java.util.*;

public class ScheduleRequest {

    public enum Frequency { MINUTELY, HOURLY, DAILY, CRON }

    private Frequency frequency;
    private Integer interval;
    private String cronExpression;
    private LocalDateTime startDateTime;
    private LocalDateTime endDateTime;
    private LocalTime windowStartTime;
    private LocalTime windowEndTime;
    private String timezone;

    // getters/setters omitted for brevity
}
