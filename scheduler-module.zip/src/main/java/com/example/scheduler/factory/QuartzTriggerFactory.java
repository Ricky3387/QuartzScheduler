
package com.example.scheduler.factory;

import com.example.scheduler.domain.ScheduleRequest;
import com.example.scheduler.util.TimezoneUtil;
import org.quartz.*;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class QuartzTriggerFactory {

    public Trigger build(String name, ScheduleRequest req) {

        Date start = TimezoneUtil.toUtcDate(req.getStartDateTime(), req.getTimezone());

        return TriggerBuilder.newTrigger()
                .withIdentity(name)
                .startAt(start)
                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInMinutes(req.getInterval())
                        .repeatForever())
                .build();
    }
}
