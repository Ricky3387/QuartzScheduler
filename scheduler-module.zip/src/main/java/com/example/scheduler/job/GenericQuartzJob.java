
package com.example.scheduler.job;

import org.quartz.*;

public class GenericQuartzJob implements Job {
    public void execute(JobExecutionContext context) {
        System.out.println("Job executed: " + context.getJobDetail().getKey());
    }
}
