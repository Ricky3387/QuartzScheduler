
package com.example.scheduler.service;

import com.example.scheduler.domain.ScheduleRequest;
import com.example.scheduler.factory.QuartzTriggerFactory;
import com.example.scheduler.job.GenericQuartzJob;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SchedulerService {

    @Autowired
    private Scheduler scheduler;

    @Autowired
    private QuartzTriggerFactory factory;

    public void schedule(String jobId, ScheduleRequest req) throws Exception {

        JobDetail job = JobBuilder.newJob(GenericQuartzJob.class)
                .withIdentity(jobId)
                .build();

        Trigger trigger = factory.build(jobId + "_trigger", req);

        scheduler.scheduleJob(job, trigger);
    }
}
