
package com.example.scheduler.util;

import java.time.*;
import java.util.Date;

public class TimezoneUtil {
    public static Date toUtcDate(LocalDateTime ldt, String timezone) {
        if (ldt == null) return null;
        return Date.from(ldt.atZone(ZoneId.of(timezone)).toInstant());
    }
}
