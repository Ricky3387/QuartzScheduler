package com.example.scheduler.controller;

import org.springframework.web.bind.annotation.*;
import com.example.scheduler.service.SchedulerService;
import com.example.scheduler.job.SampleJob;

@RestController
@RequestMapping("/api/schedules")
public class SchedulerController {

    private final SchedulerService schedulerService;

    public SchedulerController(SchedulerService schedulerService) {
        this.schedulerService = schedulerService;
    }

    @PostMapping("/{id}")
    public String create(@PathVariable String id) throws Exception {
        schedulerService.schedule(id, SampleJob.class);
        return "Scheduled " + id;
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable String id) throws Exception {
        schedulerService.delete(id);
        return "Deleted " + id;
    }
}
