package com.example.scheduler.job;

import org.quartz.*;

public class SampleJob implements Job {
    @Override
    public void execute(JobExecutionContext context) {
        System.out.println("Executing job: " + context.getJobDetail().getKey());
    }
}
