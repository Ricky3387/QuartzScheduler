package com.example.scheduler.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.scheduler.entity.ScheduleEntity;

public interface ScheduleRepository extends JpaRepository<ScheduleEntity, String> {
}
