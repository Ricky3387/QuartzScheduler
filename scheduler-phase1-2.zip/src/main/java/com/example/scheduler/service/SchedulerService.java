package com.example.scheduler.service;

import org.quartz.*;
import org.springframework.stereotype.Service;

@Service
public class SchedulerService {

    private final Scheduler scheduler;

    public SchedulerService(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

    public void schedule(String id, Class<? extends Job> jobClass) throws Exception {

        JobDetail job = JobBuilder.newJob(jobClass)
                .withIdentity(id)
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .withIdentity(id + "_trigger")
                .startNow()
                .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                        .withIntervalInSeconds(30)
                        .repeatForever())
                .build();

        scheduler.scheduleJob(job, trigger);
    }

    public void delete(String id) throws Exception {
        scheduler.deleteJob(new JobKey(id));
    }
}
