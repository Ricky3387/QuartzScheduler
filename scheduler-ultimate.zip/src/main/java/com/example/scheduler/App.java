package com.example.scheduler;
import org.springframework.boot.*;import org.springframework.boot.autoconfigure.*;
@SpringBootApplication
public class App{public static void main(String[] a){SpringApplication.run(App.class,a);}}