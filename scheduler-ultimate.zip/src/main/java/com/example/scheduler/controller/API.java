package com.example.scheduler.controller;
import org.springframework.web.bind.annotation.*;
import com.example.scheduler.service.SchedulerService;

@RestController @RequestMapping("/api")
public class API{
private final SchedulerService s;
public API(SchedulerService s){this.s=s;}

@PostMapping("/{id}")
public String create(@PathVariable String id,@RequestBody String p)throws Exception{
s.create(id,p); return "created";
}

@PutMapping("/{id}")
public String update(@PathVariable String id,@RequestBody String p)throws Exception{
s.update(id,p); return "updated";
}

@DeleteMapping("/{id}")
public String delete(@PathVariable String id)throws Exception{
s.delete(id); return "deleted";
}
}