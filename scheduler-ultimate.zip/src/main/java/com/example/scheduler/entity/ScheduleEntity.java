package com.example.scheduler.entity;
import jakarta.persistence.*;import java.time.*;
@Entity
public class ScheduleEntity{
@Id private String id;
private String payload;
public String getId(){return id;} public void setId(String id){this.id=id;}
public String getPayload(){return payload;} public void setPayload(String p){this.payload=p;}
}