package com.example.scheduler.job;
import org.quartz.*;import com.example.scheduler.kafka.EventPublisher;
public class GenericJob implements Job{
public void execute(JobExecutionContext ctx){
String id=ctx.getMergedJobDataMap().getString("id");
System.out.println("Trigger fired "+id);
}
}