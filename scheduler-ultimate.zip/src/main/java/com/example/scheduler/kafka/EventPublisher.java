package com.example.scheduler.kafka;
import org.springframework.stereotype.Component;
@Component
public class EventPublisher{
public void publish(String id){
System.out.println("Publishing event for "+id);
}
}