package com.example.scheduler.repo;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.scheduler.entity.ScheduleEntity;
public interface ScheduleRepo extends JpaRepository<ScheduleEntity,String>{}