package com.example.scheduler.service;
import org.quartz.*;import org.springframework.stereotype.Service;
import com.example.scheduler.repo.ScheduleRepo;
import com.example.scheduler.entity.ScheduleEntity;
import com.example.scheduler.job.GenericJob;
@Service
public class SchedulerService{
private final Scheduler scheduler; private final ScheduleRepo repo;
public SchedulerService(Scheduler s,ScheduleRepo r){this.scheduler=s;this.repo=r;}

public void create(String id,String payload)throws Exception{
ScheduleEntity e=new ScheduleEntity(); e.setId(id); e.setPayload(payload);
repo.save(e);
schedule(id);
}

public void update(String id,String payload)throws Exception{
delete(id); create(id,payload);
}

public void schedule(String id)throws Exception{
JobDetail job=JobBuilder.newJob(GenericJob.class)
.withIdentity(id).usingJobData("id",id).build();

Trigger trigger=TriggerBuilder.newTrigger()
.withIdentity(id+"_t")
.startNow()
.withSchedule(SimpleScheduleBuilder.simpleSchedule()
.withIntervalInSeconds(30)
.repeatForever()
.withMisfireHandlingInstructionNextWithExistingCount())
.build();

scheduler.scheduleJob(job,trigger);
}

public void delete(String id)throws Exception{
repo.deleteById(id);
scheduler.deleteJob(new JobKey(id));
}
}